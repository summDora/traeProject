/**
 * @deprecated 驾驶舱数据已迁移至 dashboardData.json（API 契约格式）
 * 本文件仅作为 scripts/buildDashboardJson.js 的数据源，业务代码请勿直接引用
 * 运行 node src/pages/GreenBiCockpit/cockpit/scripts/buildDashboardJson.js 可重新生成 JSON
 */

export const globalCountryStats = [
  { name: '中国', value: 3561978 },
  { name: '日本', value: 1625969 },
  { name: '美国', value: 979350 },
  { name: '德国', value: 534782 },
  { name: '韩国', value: 399627 },
  { name: '其它', value: 1170146 }
]

export const globalTotal = 9523556

export const globalPieData = [
  { name: '中国', y: 37.4, value: 3561978 },
  { name: '日本', y: 17.07, value: 1625969 },
  { name: '美国', y: 10.28, value: 979350 },
  { name: '德国', y: 5.62, value: 534782 },
  { name: '韩国', y: 4.2, value: 399627 },
  { name: '世界知识产权组织', y: 3.91, value: 372633 },
  { name: '欧洲', y: 3.56, value: 339015 },
  { name: '法国', y: 1.8, value: 171533 },
  { name: '英国', y: 1.67, value: 158669 },
  { name: '加拿大', y: 1.35, value: 128296 },
  { name: '其它', y: 12.29, value: 1170146 }
]

export const globalTrendYears = ["2021", "2022", "2023", "2024", "2025"]
export const globalTrendSeries = [
  { name: '中国', data: [21.04, 25.84, 28.19, 32.12, 31.16] },
  { name: '日本', data: [1.74, 1.63, 1.62, 1.7, 1.88] },
  { name: '美国', data: [2.45, 2.57, 2.59, 2.93, 2.91] },
  { name: '德国', data: [1.07, 1.0, 1.21, 1.27, 1.36] },
  { name: '韩国', data: [1.44, 1.59, 1.7, 1.88, 2.09] }
]

export const regionRanking = [
  { rank: 1, name: '广东', value: 257635 },
  { rank: 2, name: '江苏', value: 228821 },
  { rank: 3, name: '北京', value: 157235 },
  { rank: 4, name: '浙江', value: 151982 },
  { rank: 5, name: '山东', value: 96087 },
  { rank: 6, name: '上海', value: 88491 },
  { rank: 7, name: '四川', value: 63856 },
  { rank: 8, name: '安徽', value: 62552 },
  { rank: 9, name: '湖北', value: 61574 },
  { rank: 10, name: '陕西', value: 54643 },
]

export const granteeRankingDomestic = [
  { rank: 1, name: '国家电网有限公司', value: 127351 },
  { rank: 2, name: '中国电力建设集团有限公司', value: 51109 },
  { rank: 3, name: '中国南方电网有限责任公司', value: 34173 },
  { rank: 4, name: '中国华能集团有限公司', value: 29303 },
  { rank: 5, name: '国家能源投资集团有限责任公司', value: 25010 },
  { rank: 6, name: '中国核工业集团有限公司', value: 21720 },
  { rank: 7, name: '中国能源建设集团有限公司', value: 16430 },
  { rank: 8, name: '中国华电集团有限公司', value: 15778 },
  { rank: 9, name: '中国长江三峡集团有限公司', value: 14383 },
  { rank: 10, name: '国家电力投资集团有限公司', value: 13094 },
  { rank: 11, name: '中国科学院', value: 12295 },
  { rank: 12, name: '中国广核集团有限公司', value: 11921 },
  { rank: 13, name: '中国建筑集团有限公司', value: 11649 },
  { rank: 14, name: '中国电气装备集团有限公司', value: 11139 },
  { rank: 15, name: '上海电气控股集团有限公司', value: 10108 },
  { rank: 16, name: '香港中央結算（代理人）有限公司', value: 10077 },
  { rank: 17, name: '正泰集团股份有限公司', value: 9454 },
  { rank: 18, name: '中国大唐集团有限公司', value: 8098 },
  { rank: 19, name: '中国五矿集团有限公司', value: 7468 },
  { rank: 20, name: '北京国有资本运营管理有限公司', value: 6933 },
  { rank: 21, name: '清华大学', value: 5630 },
  { rank: 22, name: '阳光电源股份有限公司', value: 5423 },
  { rank: 23, name: '哈尔滨电气集团有限公司', value: 4941 },
  { rank: 24, name: '中国宝武钢铁集团有限公司', value: 4876 },
  { rank: 25, name: '通威集团有限公司', value: 4621 },
  { rank: 26, name: '中国中车集团有限公司', value: 4415 },
  { rank: 27, name: '浙江大学', value: 4370 },
  { rank: 28, name: '中国交通建设集团有限公司', value: 4357 },
  { rank: 29, name: '华为投资控股有限公司工会委员会', value: 4357 },
  { rank: 30, name: '西安交通大学', value: 4053 },
  { rank: 31, name: '中国铁路工程集团有限公司', value: 4043 },
  { rank: 32, name: '华北电力大学', value: 3912 },
  { rank: 33, name: '隆基绿能科技股份有限公司', value: 3828 },
  { rank: 34, name: '中国铁道建筑集团有限公司', value: 3828 },
  { rank: 35, name: '中天科技集团有限公司', value: 3682 },
  { rank: 36, name: '中国东方电气集团有限公司', value: 3598 },
  { rank: 37, name: 'Ji Fan Gao,', value: 3465 },
  { rank: 38, name: '国网天津市电力公司营销服务中心', value: 3429 },
  { rank: 39, name: '新疆特变电工集团有限公司', value: 3412 },
  { rank: 40, name: '珠海高瓴私募基金管理有限公司', value: 3386 },
  { rank: 41, name: '广东电网有限责任公司东莞供电局', value: 3365 },
  { rank: 42, name: '华中科技大学', value: 3331 },
  { rank: 43, name: '美的控股有限公司', value: 3140 },
  { rank: 44, name: '山西省国有资本运营有限公司', value: 3070 },
  { rank: 45, name: '东南大学', value: 3058 },
  { rank: 46, name: '亨通集团有限公司', value: 2806 },
  { rank: 47, name: '鞍钢集团有限公司', value: 2708 },
  { rank: 48, name: '中国石油化工集团有限公司', value: 2653 },
  { rank: 49, name: '上海交通大学', value: 2621 },
  { rank: 50, name: '华南理工大学', value: 2615 },
]

export const granteeRankingGlobal = [
  { rank: 1, name: '国家电网有限公司', value: 74144 },
  { rank: 2, name: '中国电力建设集团有限公司', value: 39530 },
  { rank: 3, name: '中国华能集团有限公司', value: 27797 },
  { rank: 4, name: '中国南方电网有限责任公司', value: 19255 },
  { rank: 5, name: '国家能源投资集团有限责任公司', value: 16210 },
  { rank: 6, name: '中国核工业集团有限公司', value: 15411 },
  { rank: 7, name: '中国长江三峡集团有限公司', value: 12832 },
  { rank: 8, name: '中国华电集团有限公司', value: 11714 },
  { rank: 9, name: '中国能源建设集团有限公司', value: 11024 },
  { rank: 10, name: '中国建筑集团有限公司', value: 10229 },
  { rank: 11, name: '国家电力投资集团有限公司', value: 9829 },
  { rank: 12, name: '韩国LG化学株式会社', value: 8511 },
  { rank: 13, name: '中国科学院', value: 8167 },
  { rank: 14, name: '日本制铁株式会社', value: 7900 },
  { rank: 15, name: '中国广核集团有限公司', value: 7712 },
  { rank: 16, name: '上海电气控股集团有限公司', value: 7458 },
  { rank: 17, name: 'Toyota Motor Corp.', value: 7404 },
  { rank: 18, name: '香港中央結算（代理人）有限公司', value: 7314 },
  { rank: 19, name: '华为投资控股有限公司工会委员会', value: 6714 },
  { rank: 20, name: '正泰集团股份有限公司', value: 6507 },
  { rank: 21, name: '三星电子株式会社', value: 6460 },
  { rank: 22, name: '中国电气装备集团有限公司', value: 6324 },
  { rank: 23, name: '三菱电机株式会社.', value: 6139 },
  { rank: 24, name: '株式会社日立制作所', value: 5839 },
  { rank: 25, name: 'JFE Holdings, Inc.', value: 5718 },
  { rank: 26, name: '中国大唐集团有限公司', value: 5401 },
  { rank: 27, name: 'Siemens Energy AG', value: 5145 },
  { rank: 28, name: '中国五矿集团有限公司', value: 5123 },
  { rank: 29, name: '阳光电源股份有限公司', value: 4901 },
  { rank: 30, name: '北京国有资本运营管理有限公司', value: 4877 },
  { rank: 31, name: '日本松下电器产业株式会社', value: 4603 },
  { rank: 32, name: '株式会社电装', value: 3812 },
  { rank: 33, name: '通威集团有限公司', value: 3753 },
  { rank: 34, name: '住友电气工业株式会社', value: 3746 },
  { rank: 35, name: '清华大学', value: 3620 },
  { rank: 36, name: '中国交通建设集团有限公司', value: 3563 },
  { rank: 37, name: '宁德时代新能源科技股份有限公司', value: 3508 },
  { rank: 38, name: '大韓民國政府', value: 3500 },
  { rank: 39, name: '中国铁路工程集团有限公司', value: 3442 },
  { rank: 40, name: '株式会社村田制作所', value: 3300 },
  { rank: 41, name: '株式会社东芝', value: 3264 },
  { rank: 42, name: '中国宝武钢铁集团有限公司', value: 3148 },
  { rank: 43, name: '浙江大学', value: 3139 },
  { rank: 44, name: 'Ji Fan Gao,', value: 3106 },
  { rank: 45, name: '隆基绿能科技股份有限公司', value: 3094 },
  { rank: 46, name: 'Siemens AG', value: 3071 },
  { rank: 47, name: '中国铁道建筑集团有限公司', value: 3045 },
  { rank: 48, name: 'Volkswagen AG', value: 3026 },
  { rank: 49, name: 'GE Aerospace', value: 2988 },
  { rank: 50, name: 'Schneider Electric SE', value: 2980 },
]

export const globalApplyTrendCountries = {
  categories: ["中国", "日本", "美国", "韩国", "德国"],
  data: [1535246, 139853, 95884, 94880, 43996]
}

export const globalApplyTrendOffices = {
  categories: ["中国", "美国", "世界知识产权组织", "韩国", "日本"],
  data: [1509343, 105579, 89027, 73524, 72883]
}

export const techRadarCategories = ["智能电网产业", "太阳能产业", "生物质能及其他新能源产业", "风能产业", "核电产业"]
export const techRadarData = [499395, 93449, 70100, 51047, 46843]

export const chinaPatentSummary = {
  applyTotal: 1827684,
  grantTotal: 1419281
}

export const chinaPatentTrendYears = ["2021年", "2022年", "2023年", "2024年", "2025年"]
export const chinaPatentTrendSeries = [
  { name: '申请总量', data: [381755, 390213, 434654, 405870, 215192] },
  { name: '授权总量', data: [306606, 313020, 276207, 282297, 241151] }
]

export const top50Ranking = [
  { rank: 1, name: '国家电网有限公司', value: 130898 },
  { rank: 2, name: '中国华能集团有限公司', value: 63151 },
  { rank: 3, name: '中国电力建设集团有限公司', value: 50752 },
  { rank: 4, name: '中国南方电网有限责任公司', value: 47800 },
  { rank: 5, name: '国家能源投资集团有限责任公司', value: 27353 },
  { rank: 6, name: '中国长江三峡集团有限公司', value: 22390 },
  { rank: 7, name: '中国核工业集团有限公司', value: 21256 },
  { rank: 8, name: '国家电力投资集团有限公司', value: 18457 },
  { rank: 9, name: '中国华电集团有限公司', value: 18349 },
  { rank: 10, name: '中国建筑集团有限公司', value: 17462 },
  { rank: 11, name: '中国能源建设集团有限公司', value: 14777 },
  { rank: 12, name: '中国科学院', value: 12261 },
  { rank: 13, name: '中国广核集团有限公司', value: 11470 },
  { rank: 14, name: '中国电气装备集团有限公司', value: 9351 },
  { rank: 15, name: '中国五矿集团有限公司', value: 9004 },
  { rank: 16, name: '上海电气控股集团有限公司', value: 8559 },
  { rank: 17, name: '中国大唐集团有限公司', value: 8372 },
  { rank: 18, name: '香港中央結算（代理人）有限公司', value: 7143 },
  { rank: 19, name: '正泰集团股份有限公司', value: 7052 },
  { rank: 20, name: '北京国有资本运营管理有限公司', value: 6423 },
  { rank: 21, name: '华北电力大学', value: 6299 },
  { rank: 22, name: '西安交通大学', value: 6091 },
  { rank: 23, name: '阳光电源股份有限公司', value: 6008 },
  { rank: 24, name: '清华大学', value: 5287 },
  { rank: 25, name: '华为投资控股有限公司工会委员会', value: 5241 },
  { rank: 26, name: '中国交通建设集团有限公司', value: 5221 },
  { rank: 27, name: '中国铁路工程集团有限公司', value: 5062 },
  { rank: 28, name: 'Ji Fan Gao,', value: 4973 },
  { rank: 29, name: '中国宝武钢铁集团有限公司', value: 4757 },
  { rank: 30, name: '浙江大学', value: 4680 },
  { rank: 31, name: '通威集团有限公司', value: 4519 },
  { rank: 32, name: '中国铁道建筑集团有限公司', value: 4092 },
  { rank: 33, name: '隆基绿能科技股份有限公司', value: 3737 },
  { rank: 34, name: '东南大学', value: 3612 },
  { rank: 35, name: '珠海高瓴私募基金管理有限公司', value: 3600 },
  { rank: 36, name: '中国中车集团有限公司', value: 3589 },
  { rank: 37, name: '中国东方电气集团有限公司', value: 3563 },
  { rank: 38, name: '新疆特变电工集团有限公司', value: 3531 },
  { rank: 39, name: '华中科技大学', value: 3386 },
  { rank: 40, name: '中国船舶集团有限公司', value: 3328 },
  { rank: 41, name: '国网天津市电力公司营销服务中心', value: 3289 },
  { rank: 42, name: '重庆大学', value: 3285 },
  { rank: 43, name: '哈尔滨电气集团有限公司', value: 3253 },
  { rank: 44, name: '上海交通大学', value: 3245 },
  { rank: 45, name: '晶科能源投資有限公司', value: 3203 },
  { rank: 46, name: '鞍钢集团有限公司', value: 3179 },
  { rank: 47, name: '山西省国有资本运营有限公司', value: 3125 },
  { rank: 48, name: '天津大学', value: 3109 },
  { rank: 49, name: '浙江省能源集团有限公司', value: 3055 },
  { rank: 50, name: '广东电网有限责任公司广州供电局', value: 2907 },
]

export const techFieldDistribution = [
  { name: '智能电网产业', value: 395286 },
  { name: '太阳能产业', value: 63679 },
  { name: '生物质能及其他新能源产业', value: 54179 },
  { name: '核电产业', value: 38369 },
  { name: '风能产业', value: 32012 },
]

/** 地图省份数据 — value 用于热力着色与标注 */
export const mapProvinceData = [
  { name: '广东', value: 257635 },
  { name: '江苏', value: 228821 },
  { name: '北京', value: 157235 },
  { name: '浙江', value: 151982 },
  { name: '山东', value: 96087 },
  { name: '上海', value: 88491 },
  { name: '四川', value: 63856 },
  { name: '安徽', value: 62552 },
  { name: '湖北', value: 61574 },
  { name: '陕西', value: 54643 },
]
